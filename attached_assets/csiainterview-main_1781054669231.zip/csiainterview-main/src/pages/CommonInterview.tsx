import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowLeft, Mic, MicOff, RefreshCw, Send, Square, Bookmark, Loader2, ChevronLeft, ChevronRight } from "lucide-react";
import { getRandomQuestion, COMMON_QUESTIONS } from "@/constants/questions";
import { getSchoolLabel } from "@/constants/schools";
import Footer from "@/components/Footer";
import FormattedFeedback from "@/components/FormattedFeedback";
import AudioAnalysisChart from "@/components/AudioAnalysisChart";
import VideoPreview, { VideoPreviewHandle } from "@/components/VideoPreview";
import { useSpeechRecognition } from "@/hooks/useSpeechRecognition";

interface FollowUpItem {
  question: string;
  answer: string;
  feedback: string;
  score: number | null;
}

const FollowUpQuestionCard = ({ 
  item, 
  index, 
  loading, 
  onSubmit 
}: { 
  item: FollowUpItem; 
  index: number; 
  loading: boolean;
  onSubmit: (answer: string, question: string) => Promise<void>;
}) => {
  const [nextAnswer, setNextAnswer] = useState("");
  const [showInput, setShowInput] = useState(false);

  return (
    <>
      <Card className="shadow-soft border-accent/20">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-accent">추가 질문 {index + 1}</CardTitle>
            {item.score !== null && (
              <div className="text-xl font-bold">{item.score}점</div>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-muted rounded-lg">
            <p className="font-medium">{item.question}</p>
          </div>
          <div className="p-4 bg-background rounded-lg">
            <p className="text-sm text-muted-foreground mb-2">내 답변:</p>
            <p>{item.answer}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-2">피드백:</p>
            <FormattedFeedback content={item.feedback} />
          </div>
          {!showInput && (
            <Button onClick={() => setShowInput(true)} variant="outline" className="w-full">
              추가 질문에 답변하기
            </Button>
          )}
        </CardContent>
      </Card>

      {showInput && (
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle>추가 질문 {index + 2}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="추가 답변을 입력하세요..."
              value={nextAnswer}
              onChange={(e) => setNextAnswer(e.target.value)}
              rows={6}
              className="resize-none"
            />
            <Button
              onClick={async () => {
                await onSubmit(nextAnswer, `${item.question}에 대한 추가 질문: ${item.feedback.split('\n')[0]}`);
                setNextAnswer("");
                setShowInput(false);
              }}
              disabled={loading || !nextAnswer.trim()}
              className="w-full"
            >
              <Send className="h-4 w-4 mr-2" />
              AI 피드백 받기
            </Button>
          </CardContent>
        </Card>
      )}
    </>
  );
};

const CommonInterview = () => {
  const navigate = useNavigate();
  const videoRef = useRef<VideoPreviewHandle>(null);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [feedback, setFeedback] = useState("");
  const [score, setScore] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [audioScores, setAudioScores] = useState<{
    pronunciation: number;
    speed: number;
    fluency: number;
    intonation: number;
    delivery: number;
  } | null>(null);
  const [enableCamera, setEnableCamera] = useState(false);
  const [followUpChain, setFollowUpChain] = useState<Array<{
    question: string;
    answer: string;
    feedback: string;
    score: number | null;
  }>>([]);
  const [selectedModel, setSelectedModel] = useState("google/gemini-2.5-flash");
  const [desiredSchool, setDesiredSchool] = useState("cheongshim");
  const [customSchoolInfo, setCustomSchoolInfo] = useState<any>(null);
  const [schoolQuestions, setSchoolQuestions] = useState<string[]>([]);
  const [loadingQuestions, setLoadingQuestions] = useState(false);
  const [schoolName, setSchoolName] = useState("청심국제고등학교");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  
  const { 
    transcript, 
    isListening, 
    wordCount, 
    duration,
    startListening, 
    stopListening, 
    resetTranscript 
  } = useSpeechRecognition();

  useEffect(() => {
    loadUserSettings();
  }, []);

  // Load school-specific questions when school changes
  useEffect(() => {
    if (desiredSchool === 'cheongshim') {
      // Use default questions for cheongshim
      setSchoolQuestions(COMMON_QUESTIONS);
      const randomIndex = Math.floor(Math.random() * COMMON_QUESTIONS.length);
      setCurrentQuestionIndex(randomIndex);
      setQuestion(COMMON_QUESTIONS[randomIndex]);
      setSchoolName("청심국제고등학교");
    } else if (desiredSchool) {
      // For custom schools, don't wait for customSchoolInfo - the edge function
      // will look up the cache by school key directly
      loadSchoolQuestions();
    }
  }, [desiredSchool]);

  const loadSchoolQuestions = async () => {
    setLoadingQuestions(true);
    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-common-questions`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            school: desiredSchool,
            customSchoolInfo: customSchoolInfo,
            count: 30
          }),
        }
      );

      if (!response.ok) throw new Error('Failed to load questions');

      const data = await response.json();
      if (data.questions && data.questions.length > 0) {
        setSchoolQuestions(data.questions);
        setSchoolName(data.schoolName);
        // Set first question
        const randomIndex = Math.floor(Math.random() * data.questions.length);
        setCurrentQuestionIndex(randomIndex);
        setQuestion(data.questions[randomIndex]);
      }
    } catch (error) {
      console.error('Failed to load school questions:', error);
      // Fallback to default questions
      setSchoolQuestions(COMMON_QUESTIONS);
      const randomIndex = Math.floor(Math.random() * COMMON_QUESTIONS.length);
      setCurrentQuestionIndex(randomIndex);
      setQuestion(COMMON_QUESTIONS[randomIndex]);
    } finally {
      setLoadingQuestions(false);
    }
  };

  const loadUserSettings = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data, error } = await supabase
        .from('profiles')
        .select('ai_model, enable_camera, desired_school')
        .eq('id', user.id)
        .single();
      
      if (data && !error) {
        setSelectedModel(data.ai_model || 'google/gemini-2.5-flash');
        setEnableCamera(data.enable_camera || false);
        const schoolValue = (data as any).desired_school || 'cheongshim';
        setDesiredSchool(schoolValue);
        
        // Set school name immediately for loading display
        if (schoolValue.startsWith('custom:')) {
          const customSchoolName = schoolValue.replace('custom:', '');
          setSchoolName(customSchoolName);
          try {
            const { data: schoolData } = await supabase.functions.invoke('research-school', {
              body: { schoolName: customSchoolName }
            });
            if (schoolData?.schoolInfo) {
              setCustomSchoolInfo(schoolData.schoolInfo);
              setSchoolName(schoolData.schoolInfo.name);
            }
          } catch (e) {
            console.error('Failed to load custom school info:', e);
          }
        } else {
          // Set school name from constants
          setSchoolName(getSchoolLabel(schoolValue));
        }
      }
    } else {
      // Guest user - use default questions
      setSchoolQuestions(COMMON_QUESTIONS);
      setCurrentQuestionIndex(Math.floor(Math.random() * COMMON_QUESTIONS.length));
      setQuestion(COMMON_QUESTIONS[0]);
    }
  };

  const handleNewQuestion = () => {
    const questions = schoolQuestions.length > 0 ? schoolQuestions : COMMON_QUESTIONS;
    const randomIndex = Math.floor(Math.random() * questions.length);
    setCurrentQuestionIndex(randomIndex);
    setQuestion(questions[randomIndex]);
    resetQuestionState();
  };

  const handlePrevQuestion = () => {
    const questions = schoolQuestions.length > 0 ? schoolQuestions : COMMON_QUESTIONS;
    const newIndex = currentQuestionIndex > 0 ? currentQuestionIndex - 1 : questions.length - 1;
    setCurrentQuestionIndex(newIndex);
    setQuestion(questions[newIndex]);
    resetQuestionState();
  };

  const handleNextQuestion = () => {
    const questions = schoolQuestions.length > 0 ? schoolQuestions : COMMON_QUESTIONS;
    const newIndex = currentQuestionIndex < questions.length - 1 ? currentQuestionIndex + 1 : 0;
    setCurrentQuestionIndex(newIndex);
    setQuestion(questions[newIndex]);
    resetQuestionState();
  };

  const resetQuestionState = () => {
    setAnswer("");
    setFeedback("");
    setScore(null);
    setFollowUpChain([]);
    setAudioScores(null);
    resetTranscript();
  };

  const handleSaveQuestion = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error('로그인이 필요합니다.');
      return;
    }

    try {
      const { error } = await supabase
        .from('saved_questions')
        .insert({
          user_id: user.id,
          question: question,
          source: 'common'
        });

      if (error) throw error;
      toast.success('질문이 저장되었습니다!');
    } catch (error: any) {
      toast.error('질문 저장에 실패했습니다.');
    }
  };

  const handleSubmitFollowUp = async (followUpAnswer: string, parentQuestion: string) => {
    if (!followUpAnswer.trim()) {
      toast.error('답변을 입력해주세요.');
      return;
    }

    setLoading(true);
    
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/interview-feedback`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session?.access_token}`,
          },
          body: JSON.stringify({
            question: parentQuestion,
            answer: followUpAnswer,
            type: 'common',
            isFollowUp: true,
            model: selectedModel,
            school: desiredSchool,
            customSchoolInfo: customSchoolInfo ? {
              name: customSchoolInfo.name,
              interviewFocus: customSchoolInfo.interviewFocus
            } : undefined
          }),
        }
      );

      if (!response.ok) throw new Error('Failed to get feedback');
      if (!response.body) throw new Error('No response body');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let extractedScore: number | null = null;

      // Add placeholder for streaming update
      const tempIndex = followUpChain.length;
      setFollowUpChain(prev => [...prev, {
        question: parentQuestion,
        answer: followUpAnswer,
        feedback: '',
        score: null
      }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') continue;
            
            try {
              const parsed = JSON.parse(data);
              const content = parsed.choices?.[0]?.delta?.content;
              if (content) {
                accumulatedText += content;
                
                // Update streaming content
                setFollowUpChain(prev => prev.map((item, idx) => 
                  idx === tempIndex 
                    ? { ...item, feedback: accumulatedText }
                    : item
                ));
                
                // Try to extract score with multiple patterns
                console.log('[FollowUp Score Extract] Current accumulated text length:', accumulatedText.length);
                
                if (!extractedScore) {
                  const scorePatterns = [
                    /총점\s*:?\s*(\d+)\s*점/i,
                    /총점.*?(\d+)점/i,
                    /총점[^\d]*(\d+)[^\d]/i,
                    /(\d+)\s*점.*총점/i,
                  ];
                  
                  for (const pattern of scorePatterns) {
                    const scoreMatch = accumulatedText.match(pattern);
                    if (scoreMatch) {
                      extractedScore = parseInt(scoreMatch[1]);
                      console.log('[FollowUp Score Extract] ✓ Score found:', extractedScore);
                      setFollowUpChain(prev => prev.map((item, idx) => 
                        idx === tempIndex 
                          ? { ...item, score: extractedScore }
                          : item
                      ));
                      break;
                    }
                  }
                }
              }
            } catch (e) {
              // Ignore parse errors
            }
          }
        }
      }

      // Final score extraction if not found during streaming
      if (!extractedScore) {
        console.log('[FollowUp Score Extract Final] Attempting final extraction...');
        
        const scorePatterns = [
          /^총점\s*:?\s*(\d+)\s*점/im,
          /총점\s*:?\s*(\d+)\s*점/i,
          /총점.*?(\d+)\s*점/i,
          /(\d+)\s*점/i,
        ];
        
        for (const pattern of scorePatterns) {
          const scoreMatch = accumulatedText.match(pattern);
          if (scoreMatch) {
            const potentialScore = parseInt(scoreMatch[1]);
            if (potentialScore >= 0 && potentialScore <= 110) {
              extractedScore = potentialScore;
              console.log('[FollowUp Score Extract Final] ✓ Score found:', extractedScore);
              setFollowUpChain(prev => prev.map((item, idx) => 
                idx === tempIndex 
                  ? { ...item, score: extractedScore }
                  : item
              ));
              break;
            }
          }
        }
        
        if (!extractedScore) {
          console.error('[FollowUp Score Extract Final] ✗ Failed to extract score');
        }
      }

      // Save session and award mileage
      const { data: { user } } = await supabase.auth.getUser();
      if (user && accumulatedText) {
        const { data: sessionData, error: saveError } = await supabase
          .from('interview_sessions')
          .insert({
            user_id: user.id,
            session_type: 'common',
            question: parentQuestion,
            answer: followUpAnswer,
            ai_feedback: accumulatedText,
            score: extractedScore
          })
          .select('id')
          .single();

        console.log('[Mileage Debug - FollowUp] saveError:', saveError);
        console.log('[Mileage Debug - FollowUp] extractedScore:', extractedScore);
        console.log('[Mileage Debug - FollowUp] sessionData:', sessionData);
        
        if (!saveError && extractedScore && sessionData) {
          const mileageAmount = extractedScore + 20;
          console.log('[Mileage Debug - FollowUp] Calling award_mileage with amount:', mileageAmount);
          
          const { data: mileageData, error: mileageError } = await supabase.rpc('award_mileage', {
            p_user_id: user.id,
            p_amount: mileageAmount,
            p_reason: '공통 면접 추가 질문 완료',
            p_session_id: sessionData.id
          });
          
          console.log('[Mileage Debug - FollowUp] award_mileage result:', { mileageData, mileageError });
          
          if (mileageError) {
            console.error('[Mileage Debug - FollowUp] Failed to award mileage:', mileageError);
            toast.success('피드백을 받았습니다! (마일리지 적립 실패)');
          } else {
            toast.success(`피드백을 받았습니다! +${mileageAmount} 마일리지`);
          }
        } else {
          console.log('[Mileage Debug - FollowUp] Mileage not awarded - conditions not met');
          toast.success('피드백을 받았습니다!');
        }
      } else if (!user) {
        toast.success('피드백을 받았습니다! (로그인하면 기록이 저장되고 마일리지를 받을 수 있습니다)');
      }
    } catch (error: any) {
      toast.error('피드백을 가져오는데 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  const handleVoiceAnswer = async () => {
    if (!transcript.trim()) {
      toast.error('음성 인식 결과가 없습니다.');
      return;
    }

    setLoading(true);
    setFeedback("");
    setScore(null);
    setAudioScores(null);

    try {
      const wordsPerMinute = duration > 0 ? Math.round((wordCount / duration) * 60) : 0;

      // Stop recording and get video if camera is enabled
      let videoBlob: Blob | null = null;
      let videoFrame: string | null = null;
      if (enableCamera && videoRef.current) {
        videoBlob = await videoRef.current.stopRecording();
        videoFrame = await videoRef.current.captureFrame();
      }

      const { data: { session } } = await supabase.auth.getSession();
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/interview-feedback`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session?.access_token}`,
          },
          body: JSON.stringify({
            question,
            answer: transcript,
            type: 'common_audio',
            model: selectedModel,
            school: desiredSchool,
            customSchoolInfo: customSchoolInfo ? {
              name: customSchoolInfo.name,
              interviewFocus: customSchoolInfo.interviewFocus
            } : undefined,
            audioMetrics: {
              wordsPerMinute,
              wordCount,
              duration: Math.round(duration)
            },
            videoFrame
          }),
        }
      );

      if (!response.ok) throw new Error('Failed to get feedback');
      if (!response.body) throw new Error('No response body');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let extractedScore: number | null = null;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') continue;
            
            try {
              const parsed = JSON.parse(data);
              const content = parsed.choices?.[0]?.delta?.content;
              if (content) {
                accumulatedText += content;
                setFeedback(accumulatedText);
                
                // 점수 추출 - AI 응답 첫 줄에서 추출
                if (!extractedScore && accumulatedText.length > 5) {
                  // 첫 30자 로깅
                  if (accumulatedText.length < 50) {
                    console.log('[Score Extract] First chunk:', accumulatedText);
                  }
                  
                  // 여러 패턴으로 시도
                  const scorePatterns = [
                    /^총점\s*:?\s*(\d+)\s*점/i,           // 첫 줄: 총점: 75점
                    /총점\s*:?\s*(\d+)\s*점/i,            // 어디든: 총점: 75점
                    /총점.*?(\d+)\s*점/i,                  // 총점 ... 75점
                    /(\d+)\s*점/i,                        // 75점 (숫자만)
                  ];
                  
                  for (const pattern of scorePatterns) {
                    const scoreMatch = accumulatedText.match(pattern);
                    if (scoreMatch) {
                      const potentialScore = parseInt(scoreMatch[1]);
                      // 0-110 범위 체크
                      if (potentialScore >= 0 && potentialScore <= 110) {
                        extractedScore = potentialScore;
                        console.log('[Score Extract] ✓ Score found:', extractedScore, 'Pattern:', pattern.source);
                        setScore(extractedScore);
                        break;
                      }
                    }
                  }
                  
                  if (!extractedScore && accumulatedText.length > 100) {
                    console.warn('[Score Extract] ✗ No valid score found. First 200 chars:', accumulatedText.substring(0, 200));
                  }
                }

                // Extract individual scores
                const pronunciationMatch = accumulatedText.match(/발음[^\d]*(\d+)점/);
                const speedMatch = accumulatedText.match(/속도[^\d]*(\d+)점/);
                const fluencyMatch = accumulatedText.match(/유창성[^\d]*(\d+)점/);
                const intonationMatch = accumulatedText.match(/억양[^\d]*(\d+)점/);
                const deliveryMatch = accumulatedText.match(/전달[^\d]*(\d+)점/);

                if (pronunciationMatch && speedMatch && fluencyMatch && intonationMatch && deliveryMatch) {
                  setAudioScores({
                    pronunciation: parseInt(pronunciationMatch[1]),
                    speed: parseInt(speedMatch[1]),
                    fluency: parseInt(fluencyMatch[1]),
                    intonation: parseInt(intonationMatch[1]),
                    delivery: parseInt(deliveryMatch[1])
                  });
                }
              }
            } catch (e) {
              // Ignore parse errors
            }
          }
        }
      }

      // Final score extraction with multiple attempts
      if (!extractedScore) {
        console.log('[Score Extract Final] Attempting final extraction...');
        console.log('[Score Extract Final] First 300 chars:', accumulatedText.substring(0, 300));
        
        const scorePatterns = [
          /^총점\s*:?\s*(\d+)\s*점/im,              // 첫 줄: 총점: 75점 (multiline)
          /총점\s*:?\s*(\d+)\s*점/i,               // 어디든: 총점: 75점
          /총점.*?(\d+)\s*점/i,                     // 총점 ... 75점
          /(\d+)\s*점/i,                           // 75점 (fallback)
        ];
        
        for (const pattern of scorePatterns) {
          const scoreMatch = accumulatedText.match(pattern);
          if (scoreMatch) {
            const potentialScore = parseInt(scoreMatch[1]);
            // 0-110 범위 체크
            if (potentialScore >= 0 && potentialScore <= 110) {
              extractedScore = potentialScore;
              console.log('[Score Extract Final] ✓ Score found:', extractedScore, 'Pattern:', pattern.source);
              setScore(extractedScore);
              break;
            }
          }
        }
        
        if (!extractedScore) {
          console.error('[Score Extract Final] ✗ Failed to extract score from complete text');
          console.error('[Score Extract Final] Full feedback length:', accumulatedText.length);
        }
      }

      // Save to database
      const { data: { user } } = await supabase.auth.getUser();
      console.log('[DB Save] User:', user?.id);
      console.log('[DB Save] Accumulated text length:', accumulatedText.length);
      console.log('[DB Save] Extracted score:', extractedScore);
      
      if (user && accumulatedText) {
        let videoUrl: string | null = null;

        // Upload video if available
        if (videoBlob && user) {
          const timestamp = Date.now();
          const fileName = `${user.id}/${timestamp}.webm`;
          
          const { error: uploadError } = await supabase.storage
            .from('interview-videos')
            .upload(fileName, videoBlob, {
              contentType: 'video/webm'
            });

          if (!uploadError) {
            const { data: urlData } = supabase.storage
              .from('interview-videos')
              .getPublicUrl(fileName);
            videoUrl = urlData.publicUrl;
          }
        }

        const { data: sessionData, error: saveError } = await supabase
          .from('interview_sessions')
          .insert({
            user_id: user.id,
            session_type: 'common',
            question,
            answer: transcript,
            ai_feedback: accumulatedText,
            score: extractedScore,
            video_url: videoUrl
          })
          .select('id')
          .single();

        console.log('[Mileage Debug] saveError:', saveError);
        console.log('[Mileage Debug] extractedScore:', extractedScore);
        console.log('[Mileage Debug] sessionData:', sessionData);
        
        if (!saveError && extractedScore && sessionData) {
          const mileageAmount = extractedScore + 30;
          console.log('[Mileage Debug] Calling award_mileage with amount:', mileageAmount);
          
          const { data: mileageData, error: mileageError } = await supabase.rpc('award_mileage', {
            p_user_id: user.id,
            p_amount: mileageAmount,
            p_reason: '공통 면접 연습 완료',
            p_session_id: sessionData.id
          });
          
          console.log('[Mileage Debug] award_mileage result:', { mileageData, mileageError });
          
          if (mileageError) {
            console.error('[Mileage Debug] Failed to award mileage:', mileageError);
            toast.success('피드백을 받았습니다! (마일리지 적립 실패)');
          } else {
            toast.success(`피드백을 받았습니다! +${mileageAmount} 마일리지`);
          }
        } else {
          console.log('[Mileage Debug] Mileage not awarded - conditions not met');
          toast.success('피드백을 받았습니다!');
        }
      } else if (!user) {
        toast.success('피드백을 받았습니다! (로그인하면 기록이 저장되고 마일리지를 받을 수 있습니다)');
      }
    } catch (error: any) {
      console.error('Voice analysis error:', error);
      toast.error('음성 분석에 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!answer.trim()) {
      toast.error('답변을 입력해주세요.');
      return;
    }

    setLoading(true);
    setFeedback("");
    setScore(null);
    
    try {
      // Stop recording and get video if camera is enabled
      let videoBlob: Blob | null = null;
      let videoFrame: string | null = null;
      if (enableCamera && videoRef.current) {
        if (videoRef.current.isRecording) {
          videoBlob = await videoRef.current.stopRecording();
        }
        videoFrame = await videoRef.current.captureFrame();
      }

      const { data: { session } } = await supabase.auth.getSession();
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/interview-feedback`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session?.access_token}`,
          },
          body: JSON.stringify({
            question,
            answer,
            type: 'common',
            model: selectedModel,
            videoFrame
          }),
        }
      );

      if (!response.ok) throw new Error('Failed to get feedback');
      if (!response.body) throw new Error('No response body');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let extractedScore: number | null = null;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') continue;
            
            try {
              const parsed = JSON.parse(data);
              const content = parsed.choices?.[0]?.delta?.content;
              if (content) {
                accumulatedText += content;
                setFeedback(accumulatedText);
                
                // 점수 추출 - AI 응답 첫 줄에서 추출
                if (!extractedScore && accumulatedText.length > 5) {
                  const scorePatterns = [
                    /^총점\s*:?\s*(\d+)\s*점/i,
                    /총점\s*:?\s*(\d+)\s*점/i,
                    /총점.*?(\d+)\s*점/i,
                    /(\d+)\s*점/i,
                  ];
                  
                  for (const pattern of scorePatterns) {
                    const scoreMatch = accumulatedText.match(pattern);
                    if (scoreMatch) {
                      const potentialScore = parseInt(scoreMatch[1]);
                      if (potentialScore >= 0 && potentialScore <= 110) {
                        extractedScore = potentialScore;
                        console.log('[Text Submit Score Extract] ✓ Score found:', extractedScore);
                        setScore(extractedScore);
                        break;
                      }
                    }
                  }
                }
              }
            } catch (e) {
              // Ignore parse errors for incomplete JSON
            }
          }
        }
      }

      // Final score extraction if not found during streaming
      if (!extractedScore) {
        console.log('[Text Submit Score Extract Final] Attempting final extraction...');
        console.log('[Text Submit Score Extract Final] First 300 chars:', accumulatedText.substring(0, 300));
        
        const scorePatterns = [
          /^총점\s*:?\s*(\d+)\s*점/im,
          /총점\s*:?\s*(\d+)\s*점/i,
          /총점.*?(\d+)\s*점/i,
          /(\d+)\s*점/i,
        ];
        
        for (const pattern of scorePatterns) {
          const scoreMatch = accumulatedText.match(pattern);
          if (scoreMatch) {
            const potentialScore = parseInt(scoreMatch[1]);
            if (potentialScore >= 0 && potentialScore <= 110) {
              extractedScore = potentialScore;
              console.log('[Text Submit Score Extract Final] ✓ Score found:', extractedScore);
              setScore(extractedScore);
              break;
            }
          }
        }
        
        if (!extractedScore) {
          console.error('[Text Submit Score Extract Final] ✗ Failed to extract score');
        }
      }
      
      // Save session
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        let videoUrl: string | null = null;

        // Upload video if available
        if (videoBlob && user) {
          const timestamp = Date.now();
          const fileName = `${user.id}/${timestamp}.webm`;
          
          const { error: uploadError } = await supabase.storage
            .from('interview-videos')
            .upload(fileName, videoBlob, {
              contentType: 'video/webm'
            });

          if (!uploadError) {
            const { data: urlData } = supabase.storage
              .from('interview-videos')
              .getPublicUrl(fileName);
            videoUrl = urlData.publicUrl;
          }
        }

        const { data: sessionData, error: saveError } = await supabase
          .from('interview_sessions')
          .insert({
            user_id: user.id,
            session_type: 'common',
            question,
            answer,
            ai_feedback: accumulatedText,
            score: extractedScore,
            video_url: videoUrl
          })
          .select('id')
          .single();

        // Award mileage based on score
        if (!saveError && extractedScore && sessionData) {
          const mileageAmount = extractedScore + 30; // 점수 + 30을 마일리지로 지급
          await supabase.rpc('award_mileage', {
            p_user_id: user.id,
            p_amount: mileageAmount,
            p_reason: '공통 면접 연습 완료',
            p_session_id: sessionData.id
          });
          toast.success(`피드백을 받았습니다! +${mileageAmount} 마일리지`);
        } else {
          toast.success('피드백을 받았습니다!');
        }
      } else {
        toast.success('피드백을 받았습니다! (로그인하면 기록이 저장되고 마일리지를 받을 수 있습니다)');
      }
    } catch (error: any) {
      toast.error('피드백을 가져오는데 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-secondary/5">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Button
          variant="ghost"
          onClick={() => navigate("/")}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          돌아가기
        </Button>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
          <Card className="shadow-soft">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-2xl">공통 면접 질문</CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  {schoolName} 면접 {!loadingQuestions && schoolQuestions.length > 0 && `(${currentQuestionIndex + 1}/${schoolQuestions.length})`}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handlePrevQuestion}
                  disabled={loadingQuestions}
                  title="이전 질문"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleNextQuestion}
                  disabled={loadingQuestions}
                  title="다음 질문"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleNewQuestion}
                  disabled={loadingQuestions}
                  title="랜덤 질문"
                >
                  {loadingQuestions ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4 mr-2" />
                  )}
                  랜덤
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="p-6 bg-muted rounded-lg mb-6">
                {loadingQuestions ? (
                  <div className="flex items-center justify-center gap-2 py-4">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    <span className="text-muted-foreground">{schoolName} 맞춤 질문을 생성하고 있습니다...</span>
                  </div>
                ) : (
                  <div className="flex justify-between items-start gap-4">
                    <p className="text-lg font-medium flex-1">{question}</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleSaveQuestion}
                      className="shrink-0"
                    >
                      <Bookmark className="h-4 w-4 mr-2" />
                      저장
                    </Button>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      if (enableCamera && videoRef.current && !videoRef.current.isRecording) {
                        videoRef.current.startRecording();
                      }
                      if (!isListening) startListening();
                      else stopListening();
                    }}
                    variant={isListening ? "destructive" : "default"}
                    className="flex-1"
                    disabled={loading}
                  >
                    {isListening ? (
                      <>
                        <Square className="h-4 w-4 mr-2" />
                        음성 인식 중지
                      </>
                    ) : (
                      <>
                        <Mic className="h-4 w-4 mr-2" />
                        음성으로 답변
                      </>
                    )}
                  </Button>
                  {transcript && (
                    <Button
                      onClick={handleVoiceAnswer}
                      disabled={loading}
                      className="flex-1"
                    >
                      <Send className="h-4 w-4 mr-2" />
                      음성 답변 제출
                    </Button>
                  )}
                </div>

                {transcript && (
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="text-sm font-medium text-primary">인식된 내용:</p>
                    <p className="text-sm">{transcript}</p>
                    <div className="flex gap-4 text-xs text-muted-foreground">
                      <span>단어 수: {wordCount}</span>
                      <span>속도: {duration > 0 ? Math.round((wordCount / duration) * 60) : 0} 단어/분</span>
                      <span>소요 시간: {Math.round(duration)}초</span>
                    </div>
                  </div>
                )}

                <Textarea
                  placeholder="또는 여기에 답변을 입력하세요..."
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  rows={8}
                  className="resize-none"
                />
                
                {isListening && (
                  <div className="flex items-center gap-2 text-primary animate-pulse">
                    <div className="h-3 w-3 rounded-full bg-primary" />
                    <span className="text-sm font-medium">음성 인식 중... (답변이 끝나면 중지를 클릭하세요)</span>
                  </div>
                )}

                <Button
                  onClick={handleSubmit}
                  disabled={loading || !answer.trim()}
                  className="w-full"
                >
                  {loading ? (
                    "분석 중..."
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      텍스트 답변 제출
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {feedback && (
            <Card className="shadow-soft border-primary/20">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-primary">AI 피드백</CardTitle>
                  {score !== null && (
                    <div className="text-2xl font-bold text-accent">
                      {score}점 / 100점
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormattedFeedback content={feedback} />
              </CardContent>
            </Card>
          )}

          {audioScores && (
            <AudioAnalysisChart scores={audioScores} />
          )}

          {/* Follow-up questions chain */}
          {followUpChain.map((item, index) => (
            <FollowUpQuestionCard
              key={index}
              item={item}
              index={index}
              loading={loading}
              onSubmit={handleSubmitFollowUp}
            />
          ))}
          </div>

          {enableCamera && (
            <VideoPreview ref={videoRef} />
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default CommonInterview;
